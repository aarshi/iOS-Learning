import UIKit

class Animal {
    var name:String
    
    init(n: String) {
        name = n
    }
}

class Human: Animal {
    func code() {
        print("Typing away...")
    }
}

class Fish: Animal {
    func breatheUnderWater() {
        print("Breathing under water")
    }
}

let aarshi = Human(n: "Aarshi")
let shivam = Human(n: "Shivam")
let nemo = Fish(n: "Nemo")
let num = 12
let number:NSNumber = 2
let string: NSString = "yo me"


//Even though these are of different types like human and fish, but they can be in an array as they are all Animal types, which is common part
let neighbours = [aarshi, shivam, nemo]
let neightbours1 = neighbours[0]

//This is type casting using initalization
let myDouble = 0.2
let myDoubleAsInt = Int(myDouble)

//We can use initilization for Apple classes, but for classes made by us, we need as!, as? etc

if neighbours[0] is Human {
    print("First neighbour is a human")
}

//if shivam is Human {
//    print("First neighbour is a human")
//}
//is: Type checking: This is used to check if data type on both sides of "is" is same

func findNemo(from animals:[Animal]) {
    for animal in animals {
        if animal is Fish {
            print(animal.name)
            //Even though animal is fish but we cant call methods from fish class, like so below. As it is still animal and in order to
            //animal.breatheUnderWater()
            let fish = animal as! Fish
            fish.breatheUnderWater()
            let animalFish = fish as Animal
        }
    }
}

findNemo(from: neighbours)

//as!: Forced downcast :let messageCell = cell as! MessageCell
//Here we have UITableViewCell and type casted it to subclass which is MessageCell
//Problem is that unless u r sure of type of the element you are forced downcasting is, like in this case, here we are sure that animal type is of fish for sure, but say if we have something like this:

//let fish = neighbours[1] as? Fish
//fish?.breatheUnderWater()
//It type casts neighbours[1] to optional fish
//fish? becomes an optional, so it checks if fish is nil then call breatheUnderWater function
//Can alternatively be like
if let fish = neighbours[1] as? Fish {
    fish.breatheUnderWater()
} else {
    print("Casting has failed")
}

//as?: Forced downcast : if let messageCell = cell as? MessageCell {}
//Here we are checking if element has a value then can downcast it to optinal element of subclass

//as:Upcast: It type castes object to it superclass
//let newCell = messageCell as UITableViewCell
//we do not have any "!", "?" as converting a subclass object to superclass will always work

//////////////////////////////////////////////////////
let neighbours2: [Any] = [aarshi, shivam, nemo, num]
//Any: combination of any data type: It can be classes, structs or any other data types
let neighbours3: [AnyObject] = [aarshi, shivam, nemo]
//AnyObject: It is subclass of any and contains objects derived from classes and make sure it does not contain objects from struct and Int, strings, doubles they are all structs so "num" cant be part of this array anymore.
//let neighbours4: [NSObject] = [aarshi, shivam, nemo]
//NSObject: It is subclass of anyobject and contains foundation objects, basically whatever apple has created like Nsstring, nsdata etc
//These aarshi, shivam and nemo are objects of classes and not foundation objects, like NSNUmber, NSstring, so we cannot add them in array rather we can have something like this:
let neighbour4: [NSObject] = [number, string]


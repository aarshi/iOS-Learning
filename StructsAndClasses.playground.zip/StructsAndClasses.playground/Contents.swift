import UIKit

//Classes and Structs both are blueprints with properties and functions composed in it, and we can create objects from it.

//////////////////////////////////////////////////////////////////////////////////////
//Comparisons:
//A. Structs do not inherit
//B. Structs come with init but for class you have to write init yourself
//C. Structs are immutable and if we have to do any changes then we need to write a keyword "mutating" in front
//D. If we create 2 variables from a Struct, we create copy of structs for both whereas, in class we create reference of both variables to wards that class.

//////////////////////////////////////////////////////////////////////////////////////
/////Choosing between Structs and classes by Apple:
//1. Always start creating a Struct as default, rather than a class
//2. If you need inheritance or need to access to objC code, then change that struct to class


//////////////////////////////////////////////////////////////////////////////////////
//Defining Struct
//struct myStruct {
//}

//Calling Struct
//myStruct()

struct  Enemy {
    var health: Int
    var attackStrength: Int


    mutating func takeDamage(amount: Int) {
    health = health - amount
}
}

    var skeleton1 = Enemy(health: 100, attackStrength: 10)
    var skeleton2 = skeleton1

skeleton1.takeDamage(amount: 10)
print(skeleton1.health)
print(skeleton2.health)
//In struct here, if we assign skeleton 2 as skeleton 1, then it makes a copy of it but in class it just create another reference to that object, therefore in class this is how the behavior is:

//////////////////////////////////////////////////////////////////////////////////////

//class
//Defining class
//class myClass: MySuperClass {
//}

//Calling class
//myClass()

class EnemyClass {
    var healthClass: Int
    var attackStrengthClass: Int
    
    init(health: Int, attackStrength: Int) {
        healthClass = health
        attackStrengthClass = attackStrength
    }
    
    func takeDamageClass(amount: Int) {
        healthClass = healthClass - amount
    }
}

var skeleton1Class = EnemyClass.init(health: 100, attackStrength: 10)
var sketeton2Class = skeleton1Class

skeleton1Class.takeDamageClass(amount: 10)
print(skeleton1Class.healthClass)
print(sketeton2Class.healthClass)

//Which means that if I have a photo on my laptop desktop and I want to distribute it then,
//1. In case of a struct, I will create a copy of that photo from walgreens and give it to you
//2. And in case of class, I will have to tell you the location where it is stored like, /users/aarshi/Desktop/photo.jpeg
//In struct we can make changes to copy of photo, like making whiskers in the copy and original will not be affected. Whereas, in class, if we will delete the photo from my desktop accidently then we lost that photo. That is why it is advised by Apple, to use structs by default than class.







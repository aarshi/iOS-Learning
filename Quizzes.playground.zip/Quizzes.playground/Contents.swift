import UIKit

//quizes:

//Question 1: which of these will give compiler  error?
//1.
if (true ==  true || false == true) && (true) {
}
//2.
let length5 :Float = 10.5
let width5 : Double = 5
//let area = length5 * width5
//3.
let someArray =  ["candy", 500, true] as [Any]
//4.
repeat {
    //print("value")
} while (1==1)
//Answer: 2 as we cannot apply operator in two differnt types of data types


//Question 2:  which of these is proper syntax for a function?
//1.
//function area() -> Double {
//    return length * width
//}
//It never starts with "function" rather "func"
//2.
//public Int area(Int length6, Int width6) {
//    return length6 * width6
//}
//It says return but  there is nothing to return in method declaration
//3.
//func length7: Int, width7: Int -> Int {
//    return length7 * width7
//}
//parameters go inside () in methodd declaration
//4.
func area(length8: Int32, width8: Int32) -> Int {
    return Int(length8 * width8)
}
//Answer: 4, It is taking length and  width which  is Int32 type and reeturning Int which it is type casting while returning into Int

//Question 3:  Which of these is invalid syntax?
//1.
let downloadComplete = true
if (downloadComplete) {
    print(downloadComplete)
}
//2.
if (true == false) == (true == true) || false && false && false {
    print("we made it")
}
//3.
let downloaded = 1 + 6 / 3  == 15 ? true : false
//4. None of the above
//Answer: 4


//Question 4: The following statement is an example of:
let dictionary = ["Earth": 16]
//1. Explicitly declared type
//2. An inferred type declaration
//3. Ternary operation
//4. An inexplicit type constant
//Answer: 2, it is inferred type for sure and from process of elimination it can be either 2 or 4, i can see values declared in this and not just constant defined.


//Question 5: The following contains what?
//let broke = balance <= 0 ? true : false
//1. A conditional and binary operator only
//2. Only  a unary operator
//3. A binary and ternary operator
//4. Only a ternary operator
//Answer: 3































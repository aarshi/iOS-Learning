import UIKit

//Function Syntax
//func functionName (parameter : parameterType) -> returnType {
//
//    //Does Something
//    return output
//}
////////////////////////////////////////////////////////////////////////////////////
//Three variations in functions:
//1.
//Creating function:
//func getMilk() {
//    print("Aarshi Sikka")
//}

//Calling function:
//getMilk()

//2.
//Creating function
//func getMilk (bottle: Int){
//    bottle * 5
//}

//Calling function
//getMilk(bottle: 5)

//3.
//Creating function
//func getMilk (money : Int) -> Int {
//    let change = money-2
//    return change
//}

//Calling function
//var change = getMilk(money: 4)

//We can input a function as a parameter in a function and get an output as function from it as well
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Calculator function
//func calculator (n1: Int, n2: Int) -> Int {
//    return n1 * n2
//}

//Addition function
func add (no1: Int, no2: Int) -> Int {
    return no1 + no2
}

//Calling calculator method
//calculator(n1: 2, n2: 3)

//Now, lets input this addition method into calculator method as a parameter, and in order to do that we need to boil down this "add" function into its data types.
//Now, Calculator function becomes
func calculator (n1: Int, n2: Int, operation : (Int, Int) -> Int) -> Int {
    return operation(n1, n2)
}

//Now Calling calculator method gets changes to this:
//calculator(n1: 2, n2: 3, operation: add)
//3 parameters get passed in this method
//1. n1 = 2
//2. n2 = 3
//3. Operation, which is a method
//We return Int from this function by calling operation using n1 and n2
//Whatever function we pass in as parameter, will use these n1 and n2 numbers
//So here we have passed a function as a parameter and also got a function returned from a function as well
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Now lets do the clean up and in order to cut this down, we can use closures:
//In order to convert this function into closure(It is an anonymous code which we can move freely into other functions or set as a variable) this is the process:
//func sum (firstNumber : Int, secondNumber : Int) -> Int {
//    return firstNumber + secondNumber
//}
    
//We can get rid of func and its name, move the { in front and replace it will "in"
//{ (firstNumber : Int, secondNumber : Int) -> Int in
//    return firstNumber + secondNumber
//}
    
//Addition function becomes as closure like this:
//{ (no1: Int, no2: Int) -> Int in
//    return no1 + no2
//}

//Now we can move this addition closure to where we are calling the method, which gets changed to:
//calculator(n1: 2, n2: 3, operation: { (no1: Int, no2: Int) -> Int in
//    return no1 + no2
//})

//Because we have type inference in swift, we can reduce it by removing type of input parameter and return type:
//calculator(n1: 2, n2: 3, operation: { (no1, no2) in
//    return no1 + no2
//})

//Since we are calling closure here, we know we need to return something there so we can get rid of return as well, as we only have 1 expression to be returned in and everything can be done in 1 line
//calculator(n1: 2, n2: 3, operation: { (no1, no2) in no1 + no2 })

//We can also keep the paramters as anonymous by using:
//calculator(n1: 2, n2: 3, operation: { $0 + $1 })

//We can reduce it even more as if closure is at trailing level we can get rid of parameter name:
calculator(n1: 2, n2: 3) { $0 + $1 }

//Note: Even though it cuts down the code but readability suffers
////////////////////////////////////////////////////////////////////////////////////////////////////
//Challenge
let array = [6, 2, 3, 9, 4, 1]

func addOne (n1: Int) -> Int {
    return n1 + 1
}
//Map takes another method as parameter
array.map(addOne)

//Solution
//Converting method to closure
//{ (n1: Int) -> Int in
//    return n1 + 1
//}

//Type inference reduction
//array.map({(n1) in
//    return n1 + 1
//})

//Removing return as only 1 expression is returning
//array.map({(n1) in n1 + 1})

//Traling closure and removing the
let newArray = array.map{$0 + 1}
print(newArray)

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//Closure Syntax:
//{(parameters) -> returnType in
//    statements
//}

//Reference:
//1. https://medium.com/@abhishek1nacc/closures-in-swift-85501d973333



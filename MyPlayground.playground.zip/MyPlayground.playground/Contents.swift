import UIKit

// Constant and variables
let age = 17
var myAge = 18
myAge = 19

//***************************************************************//

//Data Types
var str = "Hello, playground" //String
let myAge1 = 35 //Int
let dollarAmount = 80.60  //float
let isConnected = true //bool

//String data type
var myName = "Aarshi" //shorthand
let friend : String = "Shivam" //Longhand
         //OR
let anotherFriend : String
anotherFriend = "jack"

myName.uppercased()
myName.lowercased()
myName.capitalized
myName.hasPrefix("Aa")
myName.hasSuffix("hi")
myName.isEmpty

//Int data type
let myage2 = 23 //Shorthand
let myAge3 : Int = 35 // longhand

let x = 5
let y = 7
let z = x+y

//Float and double data type
var p : Double =  16536.267363637373737
var q : Float =  16536.267363637373737

//Boolean data type
var x1 : Bool = true
x1 = false
//OR
var y1 = false
y1 = true

//***************************************************************//

//String interpolation
let firstName = "Aarshi"
let lastName = "Sikka"
var fullName = firstName + lastName //+ is only used to concatenate strings only and  no other data types

let age4 = 35
let bodyTemp = 36.5

fullName = "My first name is \(firstName)  and last name is \(lastName) with age \(age4) and body temp \(bodyTemp)"
"If I am \(bodyTemp * 2), then I am dead"

//***************************************************************//

//Arithmetic operators
let width = 5
let height = 7
let depth = 3

width + height
width - height
width * height
width / height

(width + height) * (depth - width)

let width1 : Double = 7
let height1 : Double = 2
width1 / height1

//Remainder operator
width % height //int
width1.truncatingRemainder(dividingBy: height1) //double

//Compound Assignment operator
var e = 5
e = e + 1

e += 1
e -= 2
e /= 3
e *= 2

//Comparison Operator
width1 < height1
width1 <= height1
width1 > height1
width1 >= height1

//Checking equality
let name = "dee"
let friend1 = "Dee"
name == friend1
name ==  name //string comparison is case sensistive

//Not Operator
let widthBe = 5
let heightBe = 6

widthBe < heightBe
!(widthBe <  heightBe)

widthBe == heightBe
widthBe != heightBe

let isRaining = true
!isRaining

//Type Casting
var a = 10
var b : Double = Double (a) //changing int data type to double

a/3
b/3

var c = 10.45
var d = Int(c)
var f = Double(d)

//Swap Variables
var p1 = 10
var q1 = 5
var r1 = p1
p1 = q1
q1 = r1

//Area and perimeter
//Area of circle: pi * radius * radius
let radius = 5.0
let pi = 3.142
let area = pi * radius * radius
print("Area of my circle  is \(area)")

//Area of rectangle = length * width
//Perimeter of rectangle = 2 * (length + width)

let length3 = 8
let width3 = 10
let rectArea = length3 * width3
let perimeter = 2 * (length3 + width3)
print("Area of rectangle is \(rectArea) and perimeter is \(perimeter)")


//calulate %
// 17  fruits : 3 bananas, 5 apples, 9 pears

let bananas : Double = 3
let apples : Double = 5
let pears : Double = 9
let total : Double = 17

let bananasPerct = bananas/total * 100
let applesPerct = apples/total * 100
let pearsPerct = pears/total * 100
let totalPerct = bananasPerct + applesPerct + pearsPerct

//Last digit of a number
let num  = 1023
num % 10
num % 100
num % 1000

//If and else statement
let itWillRain = false
if itWillRain {
    print("It will rain today")
}
else {
    print("It will not rain today")
}

//Nested if/else statement (if else ke andar if else)
let myCurrentAge =  21
let myTotal = 29

if myCurrentAge > 20 {
    if myTotal > 30 {
        print("you  are over 20, and can buy")
    } else {
        print("you are not over 20 and cannot buy")
    }
} else {
    print("my age is not over 20")
}

//Else if statement
let fruit = ""
if fruit == "apple" {
    print("fruit is apple")
} else if fruit == "banana" {
    print("fruit is banana")
} else{
    print("you ate other fruit")
}

//Maximum of two numbers
let x5 = 10
let y5 = 10
if x5 > y5 {
    print("x is greater than y")
} else if y5 > x5 {
    print("y is greater than x")
} else {
    print("x and y are same")
}

//Even and odd numbers
let num35 = 35
if num35 % 2 == 0 {
    print("\(num35) is even")
} else {
    print("\(num35) is odd")
}

//Divisiblity calculations
//Check if 1023 is evenly divisible by 6
let t = 1023
let r = 6
if t % r == 0 {
    print("\(t) is evenly  divisible by \(r)")
} else {
    print("\(t) is not evenly divisible  by \(r)")
}

//Logical AND operator
//Used to check  if two conditions are simultanouesly true
let age7 = 21
let total7 = 30

if age7 > 20 && total7 >= 30 {
    print("you can make purchase")
}  else {
    print("you cannot make purchase")
}

//Both conditions must be true for AND to be true
//true && true = true
//true && false = false
//false && true = false
//false && false = false

//Logical OR Operator

if age7 == 20  || total7 == 30 {
    print("you can make purchase")
}  else {
    print("you cannot make purchase")
}

//Both conditions must be true for OR to be true
//true || true = true
//true || false = true
//false || true = true
//false || false = false

//Class Marks
let marks = 80

if marks >= 80 {
    print("Distinction")
} else if marks > 65 &&  marks < 80 {
    print("Merit")
} else if marks > 40 && marks <= 65 {
    print("Pass")
} else {
    print("Fail")
}

        //OR//

if marks <= 40 {
    print("Fail")
}  else  if marks > 40  && marks <= 65 {
    print("Pass")
} else if marks > 65 && marks < 80 {
    print("Merit")
}  else {
    print("Distinction")
}

//Divisibilty revisited
let n =  81
if n % 3 == 0 || n % 6 == 0  || n % 9 == 0  {
    print("\(n) is evenly divisible")
} else {
    print("\(n) is not evenly divisible")
}

let m = 105
if m % 3 == 0 && m % 5 == 0 && m % 7 == 0 {
    print("\(m) is evenly divisible")
} else {
    print("\(m) is not evenly divisible")
}


//Ternary conditonal operator
//Ternary means 3, it requires 3 operators
//Binary means 2, it requires 2 operators
//Unary means 1, it requires 1 operator


let myMarks = 70
let passMarks = 75
var message = ""

//Longhand
if myMarks  > passMarks {
    message = "you have passed"
} else {
    message = "you have failed"
}
print(message)

//Shorthand
message = myMarks > passMarks ? "you have passed" : "you have failed"

//Switch Statement

let numOfDrinks = 1
switch numOfDrinks {
case 0:
    print("just started, have more drink")
case 1:
    print("have more drinks")
case 2:
    print("you driving, so stop")
case 3:
    print("you are over limit")
case 4:
    print("you will be sick shorty")
default:
    print("you are drunk")
}

//Switch case matching multiple values in single case statement
//If any cas carries and matches the value, then that case will be executed.
let meal = "lasagna"

switch meal {
case "cereal", "omlette", "oat":
    print("you had breakfast")
case "rice", "lasagna":
    print("you had lunch")
default:
    print("you must have snacked")
}


//Switch range matching
let markMy = 52

switch markMy {
case 0...40:
    print("fail")
case 41...65:
    print("pass")
default:
    print("yo")
}





//Array

//Shorthand
var fruits5 = ["banana", "orange", "apple", "pears"]
var lotteryNums = [23, 12, 34, 56, 11, 67]

//Longhand
var names: [String]
names = ["james", "Bob", "Julie"]

var score : [Int] = [1,2, 4, 5, 6]

//Empty Array
var empty : [Double] = []


//Reading values from array
var fruits1 = ["pears", "apple", "banana", "orange"]
fruits1[0]
fruits1[2]
print("The best fruit is \(fruits1[1])")

fruits1.count //Tells count of array
fruits1.count - 1  //Tells index of last item  in  array

//Getting multiple values from closed range
fruits1 [1...3]

var nums2 = [1, 2, 3, 4, 5, 6]
var count = nums2.count - 1
nums2 [3...count]

//Array type and Any type
type(of: fruits1)
type(of: nums2)

//This will give compiler error, as this array have  diffent types of data in it
//var fruits3 = ["pears", "banana", 2]

var allKinds : Any =  ["pears", "banana", 2]
//let strn = allKinds [0]
//let nm = allKinds [2]

//type(of: strn)
//type(of: nm)

//Merging two arrays
//String interpolation

var str1 = "a"
var str2 = "b"
str + str2

//Joining arrays
var breakfast  = ["cereal", "egg"]
var lunch = ["sandwich", "chicken"]

var combined = breakfast + lunch

var dinner = ["salmon", "lasgna"]
combined += dinner

//Adding values to existing array

var fruits = ["pears",  "apple"]
fruits.append("banana")
fruits.append("mango")
fruits.append("pawpaw")

//Arrays can have repetitive values

//var n = [1, 2, 3]
//n += [4]
//n += [5]

// Append method and (+=) compound assignment operator is used to add values at the end of array
// But if we need need to insert values at any other position in array, we use insert method

var temp: [Double] = [34.5, 23.5, 12.4]
temp.insert(27.8, at: 0)
temp.insert(13.2, at: 3)
temp.insert(45.6, at: 2)

//Removing values from an array
var appleProducts : [String]
appleProducts = ["iPhone", "iPad", "iMac", "Macbook"]

let deleted = appleProducts.remove(at: 0)
print("we deleted \(deleted) from stock")
appleProducts

//Modifying values in array
//one way  of doing it is by pretending that we are modifying value by deleting  a  value and then inserting one in same position in order to make it look like we modified  it

//Example, we have a,b, c
//then we can  delete item at 1... so it becomes a,c
//then we can add  another item d at 1, so it becomes a,d,c
// so a,b,c becomes a,d,c, which looks to be modified


var test = [1, 2, 3]
test.remove(at: 1)
test.insert(4, at: 1)

//It is not best suggestion because there is a way to modify data quite easily
test[0] = 5
test[1] = 9
test

var fruits9  =  ["pears", "apple", "orange"]
fruits9 [0] = "mango"
fruits9

//if you use subscript outside range, then it gives error
//test [3] = 12 //this will give error, as index is out of range of array

var odd = [1, 3, 5, 7, 9, 11]
odd [3...5] = [1, 1, 1]
odd

//Be careful because you do not need to provide range with same number of items
var even = [2, 4, 6, 8, 10, 12, 14]
//even [2...5] = [0]
//even

//you do not need to provide same number of values that you are changing
//If we have all 4 numbers then it will be like this:
//even [1...5] = [0,0,0,0]
//even

//If we have 3 numbers then we will have:
even [2...5] = [0, 0, 0]
even

//Mutable and Immutable Array
//Just like, var and let for swift data types like: Int, Double etc the same applies to array.
//If you do not want array to be changed, then we use let keyword, othwewise var  keyword.

let fr = ["mango", "apple", "banana"]
//fr.append("pears")
//fr [0] =  "orange"
//This is giving error, as we aree trying to append and modify values of array which is immutable as it have let in front

//Copying value from 1 array to another array
//when you are copying array, you are simply coppying value and not the reference  so modifying 1  of copies does not have any effect on other copy
var fds = ["bob", "alice", "james"]
var invited = fds
invited.remove(at: 2)
fds.append("john")
fds
invited














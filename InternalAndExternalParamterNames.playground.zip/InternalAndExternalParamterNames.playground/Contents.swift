import UIKit

//func myFunc(name: Type) {
//    print(name)
//}
//There is only 1 parameter which is "name"

//Defining the function
//Internal And External parameter functions
//func myfunc(name eman: Type) {
//    print(enam)
//}
//Now this has 2 parameters:
//1. An external parameter name which is "name", which we will use when we call the function
//2. And internal parameter name which is "eman", whose value we will use within the function

//Calling the function
//myfunc(name: value)

//We can also omit the external parameter name by just passing the value, while calling the function
//myfunc(value)

//And function becomes:
//func myFunc(_ eman: Type) {
//    print(eman)
//}
//Here we can remove name of external parameter and replace it with underscore"_"



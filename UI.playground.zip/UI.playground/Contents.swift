import UIKit

//1. First look if you can use vertical/horizontal alignment, if there is nothing that needs to be aligned vertically/horizontaly
//2. Then look if you can  pin them with top, bottom, leading and trailing constraints, you can check by looking of those applied contraints work in landscape mode
//3. If alignment/pinning does not work then try to see if elements can be put in seperate containers(UIVIEW) and put constraints around that container(UIVIEW). Once you will put constraints to element uiview will give error saying that it needs constriants too. Thats is a lot of work now, to give constaints to both elements and then to its relative UIVIEW.
//4. Use stackviews

//Distribtion:
//A. Fill:
//1. It will keep all but one of the controls at their natural size and stretch one of them to fill the space.
//2. It determines which control to stretch by noting which one has the lowest Content Hugging Priority (CHP).
//3. If all of your controls have the same CHP, then Xcode will complain that the layout is ambiguous.


//B. Fill Equally
//1. Each control in a UIStackView will be of equal size.
//2. CHP does not matter, because each control is the same size.

//C. Fill Proportionally
//1. Ensure the controls maintain the same proportion relative to one another as your layout grows and shrinks.
//2. Unlike the previous two settings, the Fill Proportionally distribution needs the controls to have an intrinsic content size.
//3. The Fill and Fill Equally distribution tell their child controls how big they should be, but for fill proportionaly it is opposite as long as there is enough space for all of your controls to be their natural size.

//C. Equal Spacing
//1. This distribution type will maintain an equal spacing between each of the controls and will not resize the controls themselves.

//D. Equal Centering
//1. It will equally space the centers of the controls.
//2. The distance between the red lines is spaced out equally.


//Reference:
//1. https://spin.atomicobject.com/2016/06/22/uistackview-distribution/
//2. https://spin.atomicobject.com/2017/02/20/uistackview-stacking-child-views/
